from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

DIRECTIONS = ("PX", "PY", "PZ", "NX", "NY", "NZ")


@dataclass 
class Bounds:
    """Axis-aligned bounds for a cuboid."""

    xmin: float
    xmax: float
    ymin: float
    ymax: float
    zmin: float
    zmax: float

    def __post_init__(self) -> None:
        if not self.xmin < self.xmax:
            raise ValueError("Expected xmin < xmax.")
        if not self.ymin < self.ymax:
            raise ValueError("Expected ymin < ymax.")
        if not self.zmin < self.zmax:
            raise ValueError("Expected zmin < zmax.")

    @classmethod
    def from_vertices(cls, vertices: np.ndarray) -> "Bounds":
        points = np.asarray(vertices, dtype=float).reshape(-1, 3)
        return cls(
            xmin=float(points[:, 0].min()),
            xmax=float(points[:, 0].max()),
            ymin=float(points[:, 1].min()),
            ymax=float(points[:, 1].max()),
            zmin=float(points[:, 2].min()),
            zmax=float(points[:, 2].max()),
        )

    def expanded(self, extents: dict[str, float]) -> "Bounds":
        return Bounds(
            xmin=self.xmin - extents["NX"],
            xmax=self.xmax + extents["PX"],
            ymin=self.ymin - extents["NY"],
            ymax=self.ymax + extents["PY"],
            zmin=self.zmin - extents["NZ"],
            zmax=self.zmax + extents["PZ"],
        )

    def vertices(self) -> np.ndarray:
        return np.array(
            [
                [self.xmin, self.ymin, self.zmin],
                [self.xmax, self.ymin, self.zmin],
                [self.xmax, self.ymax, self.zmin],
                [self.xmin, self.ymax, self.zmin],
                [self.xmin, self.ymin, self.zmax],
                [self.xmax, self.ymin, self.zmax],
                [self.xmax, self.ymax, self.zmax],
                [self.xmin, self.ymax, self.zmax],
            ],
            dtype=float,
        )


@dataclass 
class Conductor:
    """A conductor block parsed from the input geometry."""

    name: str
    bounds: Bounds
    face_vertices: np.ndarray
    relative_permittivity: float | None = None
    
    # Compatibility properties used by the original FRW implementation.
    @property
    def min_bounds(self) -> np.ndarray:
        return np.array(
            [self.bounds.xmin, self.bounds.ymin, self.bounds.zmin],
            dtype=float,
        )

    @property
    def max_bounds(self) -> np.ndarray:
        return np.array(
            [self.bounds.xmax, self.bounds.ymax, self.bounds.zmax],
            dtype=float,
        )

    def distance_to_point(self, point: np.ndarray) -> float:
        """Chebyshev distance used by the original maximal-cube FRW."""

        point = np.asarray(point, dtype=float)
        clamped = np.maximum(
            self.min_bounds,
            np.minimum(point, self.max_bounds),
        )
        return float(np.max(np.abs(point - clamped)))

    def get_surface_normal(self, point: np.ndarray) -> np.ndarray:
        """Return the outward-facing normal of the nearest face to a point."""

        point = np.asarray(point, dtype=float)
        distances = [
            abs(point[0] - self.bounds.xmin),
            abs(point[0] - self.bounds.xmax),
            abs(point[1] - self.bounds.ymin),
            abs(point[1] - self.bounds.ymax),
            abs(point[2] - self.bounds.zmin),
            abs(point[2] - self.bounds.zmax),
        ]
        nearest_face_index = int(np.argmin(distances))
        direction = DIRECTIONS[nearest_face_index]

        if direction == "PX":
            return np.array([1.0, 0.0, 0.0], dtype=float)
        elif direction == "NX":
            return np.array([-1.0, 0.0, 0.0], dtype=float)
        elif direction == "PY":
            return np.array([0.0, 1.0, 0.0], dtype=float)
        elif direction == "NY":
            return np.array([0.0, -1.0, 0.0], dtype=float)
        elif direction == "PZ":
            return np.array([0.0, 0.0, 1.0], dtype=float)
        elif direction == "NZ":
            return np.array([0.0, 0.0, -1.0], dtype=float)
        else:
            raise ValueError(f"Unexpected face direction: {direction}")


@dataclass 
class SurfaceFace:
    """One rectangular face of a generated cuboid BGS."""

    direction: str
    vertices: np.ndarray
    normal: np.ndarray
    area: float


@dataclass 
class GaussianSurface:
    """Cuboid Boundary Gaussian Surface enclosing one master conductor."""

    master_conductor: str
    bounds: Bounds
    faces: tuple[SurfaceFace, ...]

    @property
    def area(self) -> float:
        return float(sum(face.area for face in self.faces))

    @property
    def min_bounds(self) -> np.ndarray:
        return np.array(
            [self.bounds.xmin, self.bounds.ymin, self.bounds.zmin],
            dtype=float,
        )

    @property
    def max_bounds(self) -> np.ndarray:
        return np.array(
            [self.bounds.xmax, self.bounds.ymax, self.bounds.zmax],
            dtype=float,
        )


def make_surface_faces(bounds: Bounds) -> tuple[SurfaceFace, ...]:
    """Construct the six outward-facing rectangles of a cuboid."""

    x0, x1 = bounds.xmin, bounds.xmax
    y0, y1 = bounds.ymin, bounds.ymax
    z0, z1 = bounds.zmin, bounds.zmax

    raw_faces = {
        "NX": (
            [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]],
            [-1.0, 0.0, 0.0],
            (y1 - y0) * (z1 - z0),
        ),
        "PX": (
            [[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]],
            [1.0, 0.0, 0.0],
            (y1 - y0) * (z1 - z0),
        ),
        "NY": (
            [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]],
            [0.0, -1.0, 0.0],
            (x1 - x0) * (z1 - z0),
        ),
        "PY": (
            [[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]],
            [0.0, 1.0, 0.0],
            (x1 - x0) * (z1 - z0),
        ),
        "NZ": (
            [[x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0]],
            [0.0, 0.0, -1.0],
            (x1 - x0) * (y1 - y0),
        ),
        "PZ": (
            [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]],
            [0.0, 0.0, 1.0],
            (x1 - x0) * (y1 - y0),
        ),
    }

    return tuple(
        SurfaceFace(
            direction=direction,
            vertices=np.asarray(raw_faces[direction][0], dtype=float),
            normal=np.asarray(raw_faces[direction][1], dtype=float),
            area=float(raw_faces[direction][2]),
        )
        for direction in DIRECTIONS
    )
